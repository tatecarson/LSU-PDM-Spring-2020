const synth = new Tone.Synth().toMaster(); 

synth.triggerAttackRelease('c4', '8n'); 

